<?php
 $ERROR_TEXT = "401 Unauthorized   ";
 $ERROR_DESCRIPTION = "
      This server could not verify that
      you are authorized to access. You either supplied the wrong credentials
      (e.g., bad password), or your browser doesn't understand how to supply
      the credentials required. <br />
      <br />
      In case you are allowed to request the document,
      please check your user-id and password and try again<br />
      <br />
  ";

 include ( "header.php");
?>